package com.tracfone.inquiry.sprint.controller;

import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.sprint.service.InquirySprintService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class InquirySprintControllerTest {
    private static final String MIN = "7862124910";
    private static final String SIM = "8901260892131386845";
    @MockBean
    private InquirySprintService inquirySprintService;
    @Spy
    private InquirySprintController inquirySprintController;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(inquirySprintController, "inquirySprintService", inquirySprintService);
    }

    @Test
    public void testBalanceInquiryByMin() {
        TFOneCarrierSubscriber expectedResponse = populateResponse();
        when(inquirySprintService.inquireSprintByMin(any())).thenReturn(expectedResponse);
        inquirySprintController.balanceInquiryByMin(MIN);
        verify(inquirySprintService, times(1)).inquireSprintByMin(any());
    }

    @Test
    public void testBalanceInquiryByMin_whenException() {
        doThrow(TFMicroServiceException.class).when(inquirySprintService).inquireSprintByMin(any());
        inquirySprintController.balanceInquiryByMin(MIN);
        verify(inquirySprintService, times(1)).inquireSprintByMin(any());
    }

    @Test
    public void testBalanceInquiryBySim() {
        TFOneCarrierSubscriber expectedResponse = populateResponse();
        when(inquirySprintService.inquireSprintBySim(any())).thenReturn(expectedResponse);
        inquirySprintController.balanceInquiryBySim(SIM);
        verify(inquirySprintService, times(1)).inquireSprintBySim(any());
    }

    @Test
    public void testBalanceInquiryBySim_whenException() {
        doThrow(TFMicroServiceException.class).when(inquirySprintService).inquireSprintBySim(any());
        inquirySprintController.balanceInquiryBySim(SIM);
        verify(inquirySprintService, times(1)).inquireSprintBySim(any());
    }

    private TFOneCarrierSubscriber populateResponse() {
        TFOneCarrierSubscriber tfOneCarrierSubscriber = new TFOneCarrierSubscriber();
        tfOneCarrierSubscriber.setMin(MIN);
        tfOneCarrierSubscriber.setSim(SIM);
        tfOneCarrierSubscriber.setErrorCode("200");
        return tfOneCarrierSubscriber;
    }
}