package com.tracfone.inquiry.sprint.helper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@TestPropertySource(properties = {"sprint.service.url=url",})
public class PropertyHelperTest {
    @Value("${sprint.service.url}")
    private String serviceURL;
    @Spy
    private PropertyHelper propertyHelper;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(propertyHelper, "serviceURL", serviceURL);
    }

    @Test
    public void testSettersAndGetters() {
        propertyHelper.setServiceURL(serviceURL);
        assertEquals(serviceURL, PropertyHelper.getServiceURL());
    }

}