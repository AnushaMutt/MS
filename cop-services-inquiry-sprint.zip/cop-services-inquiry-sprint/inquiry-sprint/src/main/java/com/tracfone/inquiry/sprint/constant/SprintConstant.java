package com.tracfone.inquiry.sprint.constant;

import org.omg.CORBA.PUBLIC_MEMBER;

public class SprintConstant {

    public static final String TRACFONE_CARRIER_XMLPARSE_ERROR = "TFE600";
    public static final String TRACFONE_CARRIER_XMLPARSE_ERROR_MESSAGE = "Failed to parse XML response from carrier.";
    public static final String TRACFONE_CARRIER_SIGNATURE_ERROR = "TFE700";
    public static final String TRACFONE_CARRIER_SIGNATURE_ERROR_MESSAGE = "Failed to sign request payload.";

    public static final String SPRINT_INQ_START = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sub=\"http://integration.sprint.com/interfaces/wholesaleQuerySubscription/v4/wholesaleQuerySubscriptionV4.xsd\" xmlns:v2=\"http://integration.sprint.com/common/header/WSMessageHeader/v2\">\n" +
            "                <soapenv:Header>\n" +
            "                                <v2:wsMessageHeader>\n" +
            "                                                <v2:trackingMessageHeader>\n" +
            "                                                                <v2:applicationId>2011052501</v2:applicationId>\n" +
            "                                                                <v2:applicationUserId>Tracfone</v2:applicationUserId>\n" +
            "                                                                <v2:messageId>61120_1539268218562</v2:messageId>\n" +
            "                                                                <v2:conversationId>61120</v2:conversationId>\n" +
            "                                                                <v2:timeToLive>0</v2:timeToLive>\n" +
            "                                                                <v2:messageDateTimeStamp>2018-10-11T10:30:18.562</v2:messageDateTimeStamp>\n" +
            "                                                </v2:trackingMessageHeader>\n" +
            "                                </v2:wsMessageHeader>\n" +
            "                </soapenv:Header>\n" +
            "                <soapenv:Body>\n" +
            "                                <sub:wholesaleQuerySubscriptionV4>\n" +
            "                                                <sub:searchCriteria>";

    public static final String SPRINT_INQ_END = "</sub:searchCriteria>\n" +
            "                                                <sub:historyInd>false</sub:historyInd>\n" +
            "                                </sub:wholesaleQuerySubscriptionV4>\n" +
            "                </soapenv:Body>\n" +
            "</soapenv:Envelope>";

    public static final String XPATH_RATEPLAN = "//wholesaleQuerySubscriptionV4Response/pricePlanList/pricePlanRecord/serviceCode/text()";
    public static final String XPATH_IMEI = "//wholesaleQuerySubscriptionV4Response/deviceDetailList/deviceDetailInfo/esnMeidHex/text()";
    public static final String XPATH_STATUS = "//wholesaleQuerySubscriptionV4Response/mdnList/mdnRecord/switchStatusCode/text()";
    public static final String XPATH_MIN = "//wholesaleQuerySubscriptionV4Response/mdnList/mdnRecord/mdn/text()";
    public static final String XPATH_SIM = "//wholesaleQuerySubscriptionV4Response/deviceDetailList/deviceDetailInfo/lteIccId/text()";
    public static final String XPATH_FEATURES = "//wholesaleQuerySubscriptionV4Response/detailedServiceList/serviceRecord/serviceCode";
    public static final String XPATH_FEATURES_DESCRIPTION = "//wholesaleQuerySubscriptionV4Response/detailedServiceList/serviceRecord/serviceDescription";


}
