package com.tracfone.inquiry.sprint.controller;

import com.tracfone.inquiry.common.exception.ExceptionHandlerUtil;
import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.sprint.service.InquirySprintService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Log4j2
@RestController
@RequestMapping(path = "api/sprint")
public class InquirySprintController {

    @Autowired
    InquirySprintService inquirySprintService;

    @GetMapping(value = "/inquiry/min/{minnumber}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity balanceInquiryByMin(@PathVariable("minnumber") String min) {
        log.info("Service called");
        log.info("Request received = min:" + min);
        TFOneCarrierSubscriber response = null;
        try {
            response = inquirySprintService.inquireSprintByMin(min);
        } catch (TFMicroServiceException ex) {
            response = ExceptionHandlerUtil.handleExceptions(ex);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        log.debug("Service ended");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/inquiry/sim/{simnumber}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity balanceInquiryBySim(@PathVariable("simnumber") String sim) {
        log.debug("Service called");
        log.debug("Request received = sim:" + sim);
        TFOneCarrierSubscriber response = null;
        try {
            response = inquirySprintService.inquireSprintBySim(sim);
        } catch (TFMicroServiceException ex) {
            response = ExceptionHandlerUtil.handleExceptions(ex);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        log.debug("Service ended");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
