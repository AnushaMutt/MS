package com.tracfone.inquiry.sprint.helper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PropertyHelper {

    private static String serviceURL;

    public static String getServiceURL() { return serviceURL; }

    @Value("${sprint.service.url}")
    public static void setServiceURL(String serviceURL) {
        PropertyHelper.serviceURL = serviceURL;
    }

    private static String keystoreAlias;

    public static String getKeystoreAlias() { return keystoreAlias; }

    @Value("${sprint.service.keystore.aliasname}")
    public static void setKeystoreAlias(String keystoreAlias) { PropertyHelper.keystoreAlias = keystoreAlias; }

    private static String keystoreAliasPassword;

    public static String getKeystoreAliasPassword() { return keystoreAliasPassword; }

    @Value("${sprint.service.keystore.aliaspassword}")
    public static void setKeystoreAliasPassword(String keystoreAliasPassword) { PropertyHelper.keystoreAliasPassword = keystoreAliasPassword; }

    private static String filename;

    public static String getFilename() { return filename; }

    @Value("${sprint.service.keystore.file}")
    public static void setFilename(String cryptoFileName) { PropertyHelper.filename = cryptoFileName; }

    private static String password;

    public static String getPassword() { return password; }

    @Value("${sprint.service.keystore.password}")
    public static void setPassword(String password) { PropertyHelper.password = password; }
}
