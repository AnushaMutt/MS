package com.tracfone.inquiry.sprint.service;

import com.tracfone.inquiry.common.exception.TFMicroServiceException;
import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;
import com.tracfone.inquiry.common.model.response.TFOneFeatures;
import com.tracfone.inquiry.common.model.response.TFOneRatePlan;
import com.tracfone.inquiry.common.model.response.TFOneRatePlanProfile;
import com.tracfone.inquiry.sprint.constant.SprintConstant;
import com.tracfone.inquiry.sprint.helper.PropertyHelper;
import com.tracfone.inquiry.sprint.util.SprintHttpClient;
import lombok.extern.log4j.Log4j2;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.WSSecurityException;
import org.apache.ws.security.components.crypto.CryptoFactory;
import org.apache.ws.security.message.WSSecHeader;
import org.apache.ws.security.message.WSSecSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static com.tracfone.inquiry.sprint.constant.SprintConstant.TRACFONE_CARRIER_SIGNATURE_ERROR;
import static com.tracfone.inquiry.sprint.constant.SprintConstant.TRACFONE_CARRIER_SIGNATURE_ERROR_MESSAGE;
import static com.tracfone.inquiry.sprint.constant.SprintConstant.XPATH_FEATURES;
import static com.tracfone.inquiry.sprint.constant.SprintConstant.XPATH_FEATURES_DESCRIPTION;
import static com.tracfone.inquiry.sprint.constant.SprintConstant.XPATH_IMEI;
import static com.tracfone.inquiry.sprint.constant.SprintConstant.XPATH_MIN;
import static com.tracfone.inquiry.sprint.constant.SprintConstant.XPATH_RATEPLAN;
import static com.tracfone.inquiry.sprint.constant.SprintConstant.XPATH_SIM;
import static com.tracfone.inquiry.sprint.constant.SprintConstant.XPATH_STATUS;

@Log4j2
@Service
public class InquirySprintServiceImpl implements InquirySprintService {
    @Autowired
    SprintHttpClient sprintHttpClient;

    /**
     * Inquires subscriber from SPRINT with MIN as argument.
     *
     * @param min
     * @return
     */
    public TFOneCarrierSubscriber inquireSprintByMin(String min) {
        return inquireSprint("<sub:mdn>" + min + "</sub:mdn>", TFOneCarrierSubscriber.MIN);
    }

    /**
     * Inquires subscriber from SPRINT with SIM as argument.
     *
     * @param sim
     * @return
     */
    public TFOneCarrierSubscriber inquireSprintBySim(String sim) {
        return inquireSprint("<sub:sim>" + sim + "</sub:sim>", TFOneCarrierSubscriber.SIM);
    }

    /**
     * Inquires first in Pre paid platform, if subscriber is not found, attempts
     * with Postpaid platform.
     *
     * @param searchField
     * @param searchType
     * @return
     */
    private TFOneCarrierSubscriber inquireSprint(String searchField, String searchType) {
        TFOneCarrierSubscriber subscriber = new TFOneCarrierSubscriber();
        String signedPayload = createRequestPayload(searchField);
        log.info("signed payload " + signedPayload);
        log.info("service URL " + PropertyHelper.getServiceURL());
        if (StringUtils.isEmpty(signedPayload)) {
            throw new TFMicroServiceException(TRACFONE_CARRIER_SIGNATURE_ERROR, TRACFONE_CARRIER_SIGNATURE_ERROR_MESSAGE);
        } else {
            String xmlResponse = sprintHttpClient.post(signedPayload, PropertyHelper.getServiceURL());
            log.info("xmlResponse = " + xmlResponse);
            //String xmlResponse = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\"><SOAP-ENV:Header><m:wsMessageHeader xmlns:m=\"http://integration.sprint.com/common/header/WSMessageHeader/v2\"><m:trackingMessageHeader><m:applicationId>2011052501</m:applicationId><m:applicationUserId>Tracfone</m:applicationUserId><m:consumerId/><m:messageId>7081814770_1563196702923</m:messageId><m:conversationId>7081814770</m:conversationId><m:timeToLive>0</m:timeToLive><m:replyCompletionCode>0</m:replyCompletionCode><m:messageDateTimeStamp>2019-07-15T08:18:23-05:00</m:messageDateTimeStamp></m:trackingMessageHeader></m:wsMessageHeader><wsse:Security SOAP-ENV:mustUnderstand=\"1\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"><wsu:Timestamp wsu:Id=\"Timestamp-fb4ccab8-eba1-455b-beb3-fce36d7e917a\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\"><wsu:Created>2019-07-15T13:18:23Z</wsu:Created><wsu:Expires>2019-07-15T13:23:23Z</wsu:Expires></wsu:Timestamp><wsse:BinarySecurityToken wsu:Id=\"SecurityToken-e2e9631f-5254-4aec-857e-590f59efa7c2\" EncodingType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary\" ValueType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509v3\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">MIIGUTCCBTmgAwIBAgIKIjQ43wAAAAMk6DANBgkqhkiG9w0BAQsFADBoMRMwEQYKCZImiZPyLGQBGRYDY29tMRYwFAYKCZImiZPyLGQBGRYGc3ByaW50MRIwEAYKCZImiZPyLGQBGRYCYWQxJTAjBgNVBAMTHFNwcmludCBBcHBsaWNhdGlvbiBJc3N1aW5nIDIwHhcNMTgwNTE1MTY1MjExWhcNMjIwNTE1MTcwMjExWjBiMQswCQYDVQQGEwJ1czEPMA0GA1UEChMGU3ByaW50MREwDwYDVQQLEwhQcm9qZWN0czEMMAoGA1UECxMDQk1QMQwwCgYDVQQLEwNUUEExEzARBgNVBAMTCnNwcmludC1tc28wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCn5vHzvwh055y/xysSbJ+5X2OaWmO6qhg3FzReLZl58Hg6tKfPfa/En487Lu0W2LUjcj7ZXl0/i/SxKd1aeZxWvbqZfBQy2Ry/SvcQ98A3cUCUhK9GtQDlwQqRMVRfUHCwkb9Hnr3WpgscTGCbCxDFn6b9RGr0OMtg7Oxw62b1WJ2mXhvWxbrxSCkK9DVKcJ/Klh1mmDJtRBu4Mx1rUixqs+8mKOus5PlYIRzdGBQjCBs2WRU8SwvEIoOypZ1mIhAWgtXrPqWL5xDvhDBiEosDUIJ6Pr+8yRSVYmZY+YfmluSrFmdapBAO20aNBwo9+CjWg5OK2z8dfv7QnZFtuscbAgMBAAGjggMBMIIC/TAdBgNVHQ4EFgQUu6gem91RAqGwlVFycuAvlnau9DswHwYDVR0jBBgwFoAUWcesaPrk9GCg4nDoiJ4BXnOzxwcwggFKBgNVHR8EggFBMIIBPTCCATmgggE1oIIBMYaBz2xkYXA6Ly8vQ049U3ByaW50JTIwQXBwbGljYXRpb24lMjBJc3N1aW5nJTIwMixDTj1QUEtJV0MxMCxDTj1DRFAsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1hZCxEQz1zcHJpbnQsREM9Y29tP2NlcnRpZmljYXRlUmV2b2NhdGlvbkxpc3Q/YmFzZT9vYmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludIYwaHR0cDovL2NybC5jb3JwLnNwcmludC5jb20vUFBLSVdDMTAvUFBLSVdDMTAuY3JshitodHRwOi8vY3JsLnNwcmludC5jb20vUFBLSVdDMTAvUFBLSVdDMTAuY3JsMIHZBggrBgEFBQcBAQSBzDCByTCBxgYIKwYBBQUHMAKGgblsZGFwOi8vL0NOPVNwcmludCUyMEFwcGxpY2F0aW9uJTIwSXNzdWluZyUyMDIsQ049QUlBLENOPVB1YmxpYyUyMEtleSUyMFNlcnZpY2VzLENOPVNlcnZpY2VzLENOPUNvbmZpZ3VyYXRpb24sREM9YWQsREM9c3ByaW50LERDPWNvbT9jQUNlcnRpZmljYXRlP2Jhc2U/b2JqZWN0Q2xhc3M9Y2VydGlmaWNhdGlvbkF1dGhvcml0eTALBgNVHQ8EBAMCBaAwPAYJKwYBBAGCNxUHBC8wLQYlKwYBBAGCNxUIgZLoLITX4nL9iweF7P5Ygp6PInGEnbw2hZn/TQIBZAIBDDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwEwJwYJKwYBBAGCNxUKBBowGDAKBggrBgEFBQcDAjAKBggrBgEFBQcDATANBgkqhkiG9w0BAQsFAAOCAQEAg1J0b2d5sqaAAiRPDF3AI3V7I4n3wo7/TLnXwHUEn1MVBpdOO1j57HZtzJkZd1UnqOjZZRw87nBktFwiK6EA8UGORjHklnJRf17uH/GoAifmiPAcrs1mOjUvZdusGZAF+LNt2Ryp5MF0yVLTTY5be9XfgBIs4xA70A26P7lgR+eb8sHkxBhYpGfCzNiCEzxuJqXx9Q4h2DNe95jo0CMepcTbNKnq0CXwjU7rGR2YdqYZO444WqPOctirAcpOXouPxxLMm3z6jx0+8j7c4/iUbt17p+ZoP2QvKhpRxYGuAHOLFbSVfUseekZs2acrXvJ83D775MNKYAT8w93y6vWWKg==</wsse:BinarySecurityToken><Signature xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><SignedInfo><CanonicalizationMethod Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"/><SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/><Reference URI=\"#Timestamp-fb4ccab8-eba1-455b-beb3-fce36d7e917a\"><Transforms><Transform Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"/></Transforms><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\"/><DigestValue>mO51//I9jDTXZIChD480uRcL7cM=</DigestValue></Reference><Reference URI=\"#Body-8c06f6d2-e28e-4df7-8be0-a45144dc8f4d\"><Transforms><Transform Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"/></Transforms><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\"/><DigestValue>AZB4NIyDzI8yvbO+uj8koP84W4U=</DigestValue></Reference></SignedInfo><SignatureValue>O95Sg0aknmg+o1KoEGAHzuir0v+/jEKCgdZtsPwn1EY4I/vqlRcUB68Kn1uGQuqS4B+/vsgQt1o2Myja6d1NFpHvNwmZZBvGiv0geyx0PxGFhpB1yclxlGZcnggb8kydITeqLQ4hcgAdtK4KI9oeGsZw3W1z6ID3uIvK3WEaneUkajm4gjt5IfCEnAhQKpZl7umUBCq6wfIpgKWHcy3UhvmPhmgoGnGfKtqE/xvN0ig0WSTfP1Y1157CaFca7W8a6RihUYb/7u03N1DOejoi/1QbCLRutViSBVb7n5peLjBpprW2JruiLyBbAjpGfEqe42bC5yFUuzlPdCyUfoGw1A==</SignatureValue><KeyInfo><wsse:SecurityTokenReference xmlns=\"\"><wsse:Reference URI=\"#SecurityToken-e2e9631f-5254-4aec-857e-590f59efa7c2\" ValueType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509v3\"/></wsse:SecurityTokenReference></KeyInfo></Signature></wsse:Security></SOAP-ENV:Header><SOAP-ENV:Body wsu:Id=\"Body-8c06f6d2-e28e-4df7-8be0-a45144dc8f4d\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\"><whol1:wholesaleQuerySubscriptionV4Response xmlns:whol=\"http://integration.sprint.com/interfaces/wholesaleQuerySubscriptionBt/v4/wholesaleQuerySubscriptionBtV4.xsd\" xmlns:whol1=\"http://integration.sprint.com/interfaces/wholesaleQuerySubscription/v4/wholesaleQuerySubscriptionV4.xsd\"><whol1:resellerPartnerId>2011052501</whol1:resellerPartnerId><whol1:deviceDetailList><whol1:deviceDetailInfo><whol1:deviceSerialNumber>089497012006833045</whol1:deviceSerialNumber><whol1:serialType>E</whol1:serialType><whol1:esnMeidHex>35582908684395</whol1:esnMeidHex><whol1:effectiveDate>2019-07-12</whol1:effectiveDate><whol1:effectiveTime>14:16:15</whol1:effectiveTime></whol1:deviceDetailInfo><whol1:deviceDetailInfo><whol1:deviceSerialNumber>89011201002323179246</whol1:deviceSerialNumber><whol1:serialType>U</whol1:serialType><whol1:lteImsi>310120232317924</whol1:lteImsi><whol1:lteIccId>89011201002323179246</whol1:lteIccId><whol1:effectiveDate>2019-07-12</whol1:effectiveDate><whol1:effectiveTime>14:16:15</whol1:effectiveTime></whol1:deviceDetailInfo></whol1:deviceDetailList><whol1:areMoreDevices>false</whol1:areMoreDevices><whol1:mdnList><whol1:mdnRecord><whol1:mdn>9208101068</whol1:mdn><whol1:effectiveDate>2019-07-12</whol1:effectiveDate><whol1:effectiveTime>14:16:15</whol1:effectiveTime><whol1:msid>000009202772559</whol1:msid><whol1:switchStatusCode>A</whol1:switchStatusCode></whol1:mdnRecord></whol1:mdnList><whol1:areMoreMdns>false</whol1:areMoreMdns><whol1:activationDate>2019-07-12</whol1:activationDate><whol1:reserveMdnId/><whol1:reserveDateTime>2019-07-12T14:09:31</whol1:reserveDateTime><whol1:csa>AWIAPP920</whol1:csa><whol1:currentNaiList><whol1:naiRecord><whol1:effectiveDate>2019-07-12</whol1:effectiveDate><whol1:networkStatusCode>A</whol1:networkStatusCode><whol1:nai>9208101068@MVNO87.SPRINTPCS.COM</whol1:nai></whol1:naiRecord></whol1:currentNaiList><whol1:areMorePricePlans>false</whol1:areMorePricePlans><whol1:pricePlanList><whol1:pricePlanRecord><whol1:serviceCode>TRFPLAN6</whol1:serviceCode><whol1:serviceDescription>PDA PLAN W/LTE - STRAIGHTTALK</whol1:serviceDescription><whol1:effectiveDate>2019-07-12</whol1:effectiveDate></whol1:pricePlanRecord></whol1:pricePlanList><whol1:subscriptionEffectiveDate>2019-07-12</whol1:subscriptionEffectiveDate><whol1:subscriptionId>96660547008</whol1:subscriptionId><whol1:subscriptionTypeCode>T</whol1:subscriptionTypeCode><whol1:areMoreServices>false</whol1:areMoreServices><whol1:detailedServiceList><whol1:serviceRecord><whol1:serviceCode>TRFVM</whol1:serviceCode><whol1:serviceDescription>VOICEMAIL</whol1:serviceDescription><whol1:effectiveDate>2019-07-12</whol1:effectiveDate></whol1:serviceRecord></whol1:detailedServiceList></whol1:wholesaleQuerySubscriptionV4Response></SOAP-ENV:Body></SOAP-ENV:Envelope>";
            String returnCode = getTextFromXPath(xmlResponse, "//faultcode/text()");
            log.info("returnCode = " + returnCode);
            // Check the response code
            if (returnCode == null || returnCode.isEmpty()) {
                subscriber = buildResponse(xmlResponse);
                subscriber.setLineFoundBy(searchType);
            } else {
                String faultString = getTextFromXPath(xmlResponse, "//faultstring/text()");
                log.info("faultString = " + faultString);
                subscriber.setStatus("FAILURE");
                subscriber.setErrorCode(returnCode);
                subscriber.setErrorMessage(faultString);
                subscriber.setCarrierErrorMessage(returnCode + ":" + faultString);
            }
        }
        log.info("subscriber " + subscriber);
        return subscriber;
    }

    private String createRequestPayload(String searchField) {
        String signedPayload = null;
        String payload = SprintConstant.SPRINT_INQ_START + searchField + SprintConstant.SPRINT_INQ_END;
        log.info("Unsigned payload = " + payload);
        try {
            WSSecSignature signature = new WSSecSignature();
            signature.setSignatureAlgorithm("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256");
            signature.setUserInfo(PropertyHelper.getKeystoreAlias(), PropertyHelper.getKeystoreAliasPassword());
            signature.setKeyIdentifierType(WSConstants.BST_DIRECT_REFERENCE);
            signature.setUseSingleCertificate(false);

            WSSecHeader secHeader = new WSSecHeader();
            secHeader.setMustUnderstand(false);
            Document doc = createPayloadDocument(payload);
            secHeader.insertSecurityHeader(doc);
            Document signedDoc = null;
            try {
                log.info("Property File Name " + PropertyHelper.getFilename());
                log.info("Property File Name " + PropertyHelper.getKeystoreAlias());
                Properties cxfProps = new Properties();
                cxfProps.setProperty("org.apache.ws.security.crypto.provider", "org.apache.ws.security.components.crypto.Merlin");
                cxfProps.setProperty("org.apache.ws.security.crypto.merlin.keystore.type", "jks");
                cxfProps.setProperty("org.apache.ws.security.crypto.merlin.file", PropertyHelper.getFilename());
                cxfProps.setProperty("org.apache.ws.security.crypto.merlin.keystore.password", PropertyHelper.getPassword());
                cxfProps.setProperty("org.apache.ws.security.crypto.merlin.keystore.alias", PropertyHelper.getKeystoreAlias());
                cxfProps.setProperty("org.apache.ws.security.crypto.merlin.alias.password", PropertyHelper.getKeystoreAliasPassword());

                signedDoc = signature.build(doc, CryptoFactory.getInstance(cxfProps), secHeader);
            } catch (WSSecurityException ex) {
                log.error("Error creating signed document", ex);
            }
            if (signedDoc != null) {
                signedPayload = createPayloadFromDocument(signedDoc);
            }
        } catch (Exception e) {
            log.error("Error creating signed payload", e);
        }
        return signedPayload;
    }

    private Document createPayloadDocument(String payload) {
        DocumentBuilderFactory dFactory = DocumentBuilderFactory.newInstance();
        dFactory.setNamespaceAware(true);
        Document document = null;
        try {
            DocumentBuilder dBuilder = dFactory.newDocumentBuilder();
            document = dBuilder.parse(new ByteArrayInputStream(payload.getBytes("UTF-8")));
        } catch (Exception e) {
            log.error("Could not create the document for payload " + payload, e);
        }
        return document;
    }

    private String createPayloadFromDocument(Document doc) {
        String payload = null;
        try {
            DOMSource domSource = new DOMSource(doc);
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.transform(domSource, result);
            payload = writer.toString();
        } catch (Exception e) {
            log.error("Could not create the payload for document " + doc, e);
        }
        return payload;
    }

    /**
     * Builds the subscriber response with all fields required.
     *
     * @param carrierResponse
     * @return
     */
    public TFOneCarrierSubscriber buildResponse(String carrierResponse) {

        TFOneCarrierSubscriber subscriber = new TFOneCarrierSubscriber();
        String xPathRatePlan = XPATH_RATEPLAN;
        String xPathIMEI = XPATH_IMEI;
        String xPathStatus = XPATH_STATUS;
        String xPathMin = XPATH_MIN;
        String xPathSim = XPATH_SIM;
        String xPathFeatures = XPATH_FEATURES;
        String xPathFeaturesDescriptions = XPATH_FEATURES_DESCRIPTION;

        String ratePlan = getTextFromXPath(carrierResponse, xPathRatePlan);
        String imei = getTextFromXPath(carrierResponse, xPathIMEI);
        String status = getTextFromXPath(carrierResponse, xPathStatus);
        String min = getTextFromXPath(carrierResponse, xPathMin);
        String sim = getTextFromXPath(carrierResponse, xPathSim);

        ArrayList<String> features = nodeListToStrList(getValueFromXPath(carrierResponse, xPathFeatures));
        ArrayList<String> featuresDescription = nodeListToStrList(getValueFromXPath(carrierResponse, xPathFeaturesDescriptions));
        TFOneRatePlan tfRatePlan = buildRatePlanProfile(features, featuresDescription, ratePlan);

        subscriber.setEsn(imei);
        subscriber.setRateplanProfile(tfRatePlan);
        subscriber.setLineStatus(getReadableStatus(status));
        subscriber.setMin(min);
        subscriber.setSim(sim);
        return subscriber;
    }

    private NodeList getValueFromXPath(String carrierResponse, String xPath) {
        NodeList nodeList = null;

        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(new InputSource(new StringReader(carrierResponse)));
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr = xpath.compile(xPath);
            nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
        } catch (Exception e) {
            throw new TFMicroServiceException(SprintConstant.TRACFONE_CARRIER_XMLPARSE_ERROR,
                    SprintConstant.TRACFONE_CARRIER_XMLPARSE_ERROR_MESSAGE, e.getMessage(), e);
        }

        return nodeList;
    }

    private String getTextFromXPath(String carrierResponse, String xPath) {
        String nodeValue = null;
        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(new InputSource(new StringReader(carrierResponse)));
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr = xpath.compile(xPath);
            nodeValue = expr.evaluate(doc);
        } catch (Exception e) {
            throw new TFMicroServiceException(SprintConstant.TRACFONE_CARRIER_XMLPARSE_ERROR,
                    SprintConstant.TRACFONE_CARRIER_XMLPARSE_ERROR_MESSAGE, e.getMessage(), e);
        }
        return nodeValue;
    }

    private ArrayList<String> nodeListToStrList(NodeList nodeList) {
        ArrayList<String> strList = new ArrayList<>();
        for (int x = 0; x < nodeList.getLength(); x++) {
            Node node = nodeList.item(x);
            strList.add(node.getTextContent());
        }
        return strList;
    }

    /**
     * @param features
     * @param ratePlan
     * @return built object with rate plan and features.
     */
    private TFOneRatePlan buildRatePlanProfile(ArrayList<String> features, ArrayList<String> featuresDescriptions, String ratePlan) {
        TFOneRatePlan tfRatePlan = new TFOneRatePlan();
        tfRatePlan.setRatePlanName(ratePlan);
        List<TFOneFeatures> tfFeatures = new ArrayList<>();

        TFOneFeatures tfFeat;
        for (int i = 0; i < features.size(); i++) {
            tfFeat = new TFOneFeatures();
            tfFeat.setFeatureValue(features.get(i));
            tfFeat.setFeatureName(featuresDescriptions.get(i));
            tfFeatures.add(tfFeat);
        }

        TFOneRatePlanProfile tfRateplanProfile = new TFOneRatePlanProfile();
        tfRateplanProfile.setFeatures(tfFeatures);
        List<TFOneRatePlanProfile> ratePlanProfile = new ArrayList<>();
        ratePlanProfile.add(tfRateplanProfile);

        tfRatePlan.setRatePlanProfile(ratePlanProfile);
        return tfRatePlan;
    }

    /**
     * @param status
     * @return readable status of SPRINT line.
     */
    private String getReadableStatus(String status) {
        switch (status) {
            case "A":
                return TFOneCarrierSubscriber.LINE_STATUS_ACTIVE;
            case "S":
                return TFOneCarrierSubscriber.LINE_STATUS_SUSPENDED;
            case "C":
                return TFOneCarrierSubscriber.LINE_STATUS_CANCELED;
            case "R":
                return TFOneCarrierSubscriber.LINE_STATUS_RESERVED;
            default:
                return status;
        }
    }
}
