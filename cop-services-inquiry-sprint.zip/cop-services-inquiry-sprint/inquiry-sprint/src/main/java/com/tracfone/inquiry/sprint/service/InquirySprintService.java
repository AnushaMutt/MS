package com.tracfone.inquiry.sprint.service;

import com.tracfone.inquiry.common.model.response.TFOneCarrierSubscriber;

public interface InquirySprintService {
    TFOneCarrierSubscriber inquireSprintByMin(String min);

    TFOneCarrierSubscriber inquireSprintBySim(String sim);
}
