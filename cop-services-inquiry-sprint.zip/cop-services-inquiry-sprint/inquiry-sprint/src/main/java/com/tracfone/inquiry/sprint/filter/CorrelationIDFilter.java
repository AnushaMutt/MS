package com.tracfone.inquiry.sprint.filter;

import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

@Log4j2
@Component
public class CorrelationIDFilter extends OncePerRequestFilter {

    public static final String CORRELATION_ID_KEY = "X-Correlation-ID";

    @Override
    protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
                                    final FilterChain filterChain) throws ServletException, IOException {
        try {
            final String correlationID = StringUtils.isEmpty(request.getHeader(CORRELATION_ID_KEY)) ? UUID.randomUUID().toString() : request.getHeader(CORRELATION_ID_KEY);
            ThreadContext.put(CORRELATION_ID_KEY, correlationID);
            response.addHeader(CORRELATION_ID_KEY, correlationID);
            filterChain.doFilter(request, response);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    @Override
    protected boolean isAsyncDispatch(final HttpServletRequest request) {
        return false;
    }

    @Override
    protected boolean shouldNotFilterErrorDispatch() {
        return false;
    }
}
