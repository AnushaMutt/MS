package com.tracfone.inquiry.sprint.config;

import com.tracfone.inquiry.sprint.filter.CorrelationIDFilter;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.client.RestTemplate;

@Configuration
public class AppConfig {

    @Bean
    public FilterRegistrationBean<CorrelationIDFilter> servletRegistrationBean() {
        FilterRegistrationBean<CorrelationIDFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new CorrelationIDFilter());
        registrationBean.setOrder(Ordered.LOWEST_PRECEDENCE);
        return registrationBean;
    }

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder.build();
    }
}
